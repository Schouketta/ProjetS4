#include "Arete.h"
/***************************************************
                    Arete
****************************************************/

/// Le constructeur met en place les �l�ments de l'interface
AreteInterface::AreteInterface(Sommet& from, Sommet& to)
{
    // Le WidgetArete de l'interface de l'arc
    if ( !(from.m_interface && to.m_interface) )
    {
        std::cerr << "Error creating AreteInterface between vertices having no interface" << std::endl;
        throw "Bad AreteInterface instanciation";
    }
    m_top_Arete.attach_from(from.m_interface->m_top_box);
    m_top_Arete.attach_to(to.m_interface->m_top_box);
    m_top_Arete.reset_arrow_with_bullet();

    // Une boite pour englober les widgets de r�glage associ�s
    m_top_Arete.add_child(m_box_Arete);
    m_box_Arete.set_dim(24,60);
    m_box_Arete.set_bg_color(BLANCBLEU);

    // Le slider de r�glage de valeur
    m_box_Arete.add_child( m_slider_weight );
    m_slider_weight.set_range(0.0 , 100.0); // Valeurs arbitraires, � adapter...
    m_slider_weight.set_dim(16,40);
    m_slider_weight.set_gravity_y(grman::GravityY::Up);

    // Label de visualisation de valeur
    m_box_Arete.add_child( m_label_weight );
    m_label_weight.set_gravity_y(grman::GravityY::Down);

}


/// Gestion du Arete avant l'appel � l'interface
void Arete::pre_update()
{
    if (!m_interface)
        return;

    /// Copier la valeur locale de la donn�e m_weight vers le slider associ�
    m_interface->m_slider_weight.set_value(m_weight);

    /// Copier la valeur locale de la donn�e m_weight vers le label sous le slider
    m_interface->m_label_weight.set_message( std::to_string( (int)m_weight ) );
}

/// Gestion du Arete apr�s l'appel � l'interface
void Arete::post_update()
{
    if (!m_interface)
        return;

    /// Reprendre la valeur du slider dans la donn�e m_weight locale
    m_weight = m_interface->m_slider_weight.get_value();
}


void Arete::setIndice(int idx)
{
    m_indiceArete=idx;
}
